package com.cg.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.book.dao.CategoryDao;
import com.cg.book.dto.AddCategory;
import com.cg.book.dto.Category;
import com.cg.book.exception.BookException;
@Service
public class bookServiceImpl implements BookService {
    @Autowired
	private CategoryDao dao;
	@Override
	public List<Category> getAllCategories() throws BookException {
	 return  dao.findAll();
	}
	@Override
	public String addCategory(AddCategory category) throws BookException {
		Category c= new Category();
		
		String name=category.getCategoryName();
		System.out.println(name);
		c.setCategoryName(name);
		dao.save(c);
		return "added successfully";
	}

}
