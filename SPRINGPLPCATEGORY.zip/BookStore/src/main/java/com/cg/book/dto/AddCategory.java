package com.cg.book.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AddCategory {
	@Id
	private String categoryName;

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public AddCategory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddCategory(String categoryName) {
		super();
		this.categoryName = categoryName;
	}
	
	

}
