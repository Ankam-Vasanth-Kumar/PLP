package com.cg.book.service;

import java.util.List;

import com.cg.book.dto.AddCategory;
import com.cg.book.dto.Category;
import com.cg.book.exception.BookException;

public interface BookService {

	List<Category> getAllCategories() throws BookException;

	String addCategory(AddCategory category)throws BookException;

}
