export class AddCateggory {
    categoryname:string;

    constructor(categoryname:string){
        this.categoryname=categoryname;
    }
}
