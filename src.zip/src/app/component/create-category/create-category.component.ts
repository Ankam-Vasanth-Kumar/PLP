import { Component, OnInit } from '@angular/core';
import { AddCateggory } from 'src/app/bean/add-categgory';
import { CategoryService } from 'src/app/service/category.service';
import { AddCategory } from 'src/app/bean/add-category';

@Component({
  selector: 'app-create-category',
  templateUrl: './create-category.component.html',
  styleUrls: ['./create-category.component.css']
})
export class CreateCategoryComponent implements OnInit {
category:AddCategory={"categoryName":''};
  constructor(private service:CategoryService) { }

  ngOnInit() {
  }
add(){
this.service.addCategory(this.category).subscribe();
alert('added successfully');
}
}
