import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { ShowCategoryComponent } from './component/show-category/show-category.component';
import { createComponent } from '@angular/compiler/src/core';
import { CreateCategoryComponent } from './component/create-category/create-category.component';
import { EditCategoryComponent } from './component/edit-category/edit-category.component';


const routes: Routes = [
{path:'',redirectTo:'welcome',pathMatch:'full'},
{path:'welcome',component:WelcomeComponent},
{path:'welcome/category',component:ShowCategoryComponent},
{path:'welcome/category/create',component:CreateCategoryComponent},
{path:'welcome/category/edit',component:EditCategoryComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
