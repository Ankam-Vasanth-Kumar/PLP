export class Category {
    ID:number;
    CategoryName:String;
}
