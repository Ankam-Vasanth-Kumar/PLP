export class AddCateggory {
    categoryName:string;

    constructor(categoryName:string){
        this.categoryName=categoryName;
    }
}
