import { AddCategory } from './add-category';

describe('AddCategory', () => {
  it('should create an instance', () => {
    expect(new AddCategory()).toBeTruthy();
  });
});
