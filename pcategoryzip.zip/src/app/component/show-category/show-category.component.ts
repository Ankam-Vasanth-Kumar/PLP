import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/bean/category';
import { CategoryService } from 'src/app/service/category.service';

@Component({
  selector: 'app-show-category',
  templateUrl: './show-category.component.html',
  styleUrls: ['./show-category.component.css']
})
export class ShowCategoryComponent implements OnInit {
category:Category;
  constructor(private service:CategoryService) { }

  ngOnInit() {
      this.service.getAllCategories().subscribe(data=>{this.category=data});
  }
public showCategory(){
 
}
deleteCategory(id:number){
  this.service.deleteCategory(id);
 // this.category=this.service.getAllCategories().subscribe(data=>{this.category=data});
 this.service.getAllCategories().subscribe(data=>{this.category=data});
}



}