package com.cg.book.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.book.dto.Category;
import com.cg.book.exception.BookException;
@Repository
public interface CategoryDao extends JpaRepository<Category, Integer>{
	@Query("from Category order by CategoryName")
	public List<Category> getAllCategories()throws BookException;

}
