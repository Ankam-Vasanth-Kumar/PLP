package com.cg.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.book.dto.Category;
import com.cg.book.exception.BookException;
import com.cg.book.service.BookService;


@CrossOrigin("http://localhost:4020")
@RestController
public class CategoryController {
	@Autowired
	private BookService bookservice;
	
	@GetMapping("/allCategories")
	public List<Category> getAllCategories() throws BookException{
		return bookservice.getAllCategories();
	}
	
	@PostMapping("/addCategory")
	public String addCategory(@RequestBody Category category) throws BookException {
		return bookservice.addCategory(category);
	}
	
	@DeleteMapping("/deleteCategory/{id}")
	public List<Category> deleteCategory(@PathVariable int id) throws BookException{
		return bookservice.deleteCategory(id);
	}
	
	@GetMapping("/getCategory/{id}")
	public Category getCategory(@PathVariable int id)throws BookException {
		return bookservice.getCategory(id);
	}
@PutMapping("/updateCategory/{id}")
public String updateCategory(@PathVariable int id,@RequestBody Category category) throws BookException {
	return bookservice.updateCategory(id, category);
}

	@ExceptionHandler(BookException.class)
	public ResponseEntity<String> handleException(Exception ex){
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
		
	}
	

}
