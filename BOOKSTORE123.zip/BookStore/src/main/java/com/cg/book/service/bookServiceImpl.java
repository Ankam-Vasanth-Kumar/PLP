package com.cg.book.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.book.dao.CategoryDao;

import com.cg.book.dto.Category;
import com.cg.book.exception.BookException;
@Service
public class bookServiceImpl implements BookService {
    @Autowired
	private CategoryDao dao;
    
	@Override
	public List<Category> getAllCategories() throws BookException {
	 return  dao.getAllCategories();
	}
	@Override
	public String addCategory(Category category) throws BookException {
		
		dao.save(category);
		
		return "added successfully";
	}
	@Override
	public List<Category> deleteCategory(int id) throws BookException {
		// TODO Auto-generated method stub
		 dao.deleteById(id);
		 return dao.getAllCategories();
	}
	@Override
	public Category getCategory(int id) throws BookException {
		Category cg=dao.findById(id).get();
		System.out.println(cg.getCategoryName());
		return cg;
	}
	@Override
	public String updateCategory(int id, Category category) throws BookException {
		if(dao.existsById(id)) {
			Category cat=dao.findById(id).get();
			String name=category.getCategoryName();
			System.out.println(name);
			cat.setCategoryName(name);
			dao.save(cat);
		}
		return "updated Successfully";	}

}
