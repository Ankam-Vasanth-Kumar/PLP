package com.cg.book.service;

import java.util.List;


import com.cg.book.dto.Category;
import com.cg.book.exception.BookException;

public interface BookService {

	List<Category> getAllCategories() throws BookException;

	String addCategory(Category category)throws BookException;

	List<Category> deleteCategory(int id)throws BookException;

	Category getCategory(int id)throws BookException;

	String updateCategory(int id, Category category)throws BookException;

}
