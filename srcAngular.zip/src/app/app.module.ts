import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddCustomerComponent } from './component/add-customer/add-customer.component';

import { WithdrawComponent } from './component/withdraw/withdraw.component';
import { DepositComponent } from './component/deposit/deposit.component';
import { ShowBalanceComponent } from './component/show-balance/show-balance.component';
import { TransactionsComponent } from './component/transactions/transactions.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { BankService } from './service/bank.service';

@NgModule({
  declarations: [
    AppComponent,
    AddCustomerComponent,
   
    WithdrawComponent,
    DepositComponent,
    ShowBalanceComponent,
    TransactionsComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BankService],
  bootstrap: [AppComponent]
})
export class AppModule { }
