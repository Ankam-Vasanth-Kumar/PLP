export class Transaction {
    transId:number;
    transType:String;
    transDate:Date;
    fromAccountNo:number;
    toAccountNo:number;
    amount:number;
    balance:number;
    constructor(transId:number,
        transType:String,
        transDate:Date,
        fromAccountNo:number,
        toAccountNo:number,
        amount:number,
        balance:number){
            this.transId=transId;
            this.transType=transType;
            this.transDate=transDate;
            this.fromAccountNo=fromAccountNo;
            this.toAccountNo=toAccountNo;
            this.amount=amount;
            this.balance=balance;

    }
}
