export class Category {
    id:number;
    categoryName:String;
   
}
