export class LoginData {
    email:string;
    password:string;
}
