import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddCustomerComponent } from './component/add-customer/add-customer.component';


import { ShowBalanceComponent } from './component/show-balance/show-balance.component';
import { DepositComponent } from './component/deposit/deposit.component';
import { WithdrawComponent } from './component/withdraw/withdraw.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { TransactionsComponent } from './component/transactions/transactions.component';


const routes: Routes = [
  {path:'',redirectTo:'welcome',pathMatch:'full'},
  { path: 'welcome/create', component: AddCustomerComponent },
  
 
  {path:'welcome/balance',component:ShowBalanceComponent},
  {path:'welcome/deposit',component:DepositComponent},
  {path:'welcome/withdraw',component:WithdrawComponent},
  {path:'welcome/transaction',component:TransactionsComponent},
  {path:'welcome',component:WelcomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
