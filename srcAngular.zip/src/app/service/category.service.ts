import { Injectable } from '@angular/core';
import { Category } from '../bean/category';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddCateggory } from '../bean/add-categgory';
import { AddCategory } from '../bean/add-category';
import { LoginData } from '../bean/login-data';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categories:Category[];
  private userUrl = 'http://localhost:4000';
  constructor(private http: HttpClient) { }

public getAllCategories():Observable<Category[]>{
return this.http.get<Category[]>(this.userUrl+'/allCategories');
  }

  public addCategory(category: Category): Observable<AddCategory> {
    return this.http.post<AddCategory>(this.userUrl + '/addCategory', category);
  }
  deleteCustomer(categ:Category){
    return this.http.delete<Category[]>(this.userUrl+"/deleteCategory/"+categ.id);
  }
  getCategory(id:number):Observable<Category>{
    return this.http.get<Category>(this.userUrl+"/getCategory/"+id);
  }
  updateCategory(categ:Category){
    return this.http.put(this.userUrl+"/updateCategory/"+categ.id,categ);
  }
  validlogin(login:LoginData):Observable<LoginData>{
    return this.http.get<LoginData>(this.userUrl+'/login/'+login.email);
  }
}
