import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/bean/customer';
import { BankService } from 'src/app/service/bank.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {
customer:Customer={"name":'',"email":'',"mobile":'',"address":'',"amount":0};
  constructor(private bankService:BankService) { }

  ngOnInit() {
  }
add(){
  this.bankService.addCustomer(this.customer).subscribe();
  alert("added successfully");
}
}
