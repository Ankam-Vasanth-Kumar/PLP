import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/bean/category';
import { CategoryService } from 'src/app/service/category.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-category',
  templateUrl: './show-category.component.html',
  styleUrls: ['./show-category.component.css']
})
export class ShowCategoryComponent implements OnInit {
category:Category[];
  constructor(private service:CategoryService, private router:Router) { }

  ngOnInit() {
      this.service.getAllCategories().subscribe(data=>{this.category=data});
    
  }
 
    


  deleteCategory(categ:Category){
    if(window.confirm("Are you sure you want to delete the user with id "+categ.id)){
    this.service.deleteCustomer(categ).subscribe();
    this.service.getAllCategories().subscribe(data=>{this.category=data});
  }
}
editCategory(categ:Category){
  this.router.navigate(['welcome/category/edit']);}
}



