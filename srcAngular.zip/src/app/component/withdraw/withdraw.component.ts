import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/bean/account';
import { BankService } from 'src/app/service/bank.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  accnt:Account;
  accnt1:Account;
  amount:number;
  message:string;
  flag:number=0;
  constructor(private service:BankService) { }

  ngOnInit() {
  }
  withdraw(accNo:number,amount:number)
  {
  if(accNo!=0)
  {
  this.accnt={"name":'',"accountNo":0,"password":0,"balance":amount};
  
  this.service.withDraw(accNo,this.accnt).subscribe(data=>{this.accnt1=data;
    
  if(this.accnt1.balance>amount){this.message=' Hello'+data.name+'   '+' withdrawn succesfuuly'}
  
});
if(this.flag==1){
  alert("withdraw successfull");
  }
  
    }
  }
}
